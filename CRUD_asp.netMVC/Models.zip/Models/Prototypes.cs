﻿namespace CRUD_asp.netMVC.Models
{
    public class Prototypes
    {
    }
}
