﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CRUD_asp.netMVC.Models
{
    public class Manufactures
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string? ID { get; set; }

        public string? Name { get; set; }

        public List<Products>? products { get; set; }
    }
}
