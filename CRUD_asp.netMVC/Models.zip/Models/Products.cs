﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Net.NetworkInformation;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace CRUD_asp.netMVC.Models
{
    public class Products
    {
        [Key]
        [DisplayName("Hien thi ID: ")]
        public int ID { get; set; }

        [StringLength(50, MinimumLength = 5, ErrorMessage = "Do dai ten tu {2} den {1} ky tu")]
        [Column(TypeName = "nvarchar(50)")]
        [Required(ErrorMessage = "Ban can phai nhap Ten !!!")]
        public string? Name { get; set; }

        [NotMapped]
        [DataType(DataType.Upload)]
        [Required(ErrorMessage = "Ban can phai them anh san pham !!!")]
        public IFormFile[]? picture { get; set; }
        
        public string? PicturePath { get; set; }

        [DisplayName("Hien thi mo ta: ")]
        [StringLength(300, MinimumLength = 3, ErrorMessage = "Do dai mo ta tu {2} den {1} ky tu")]
        [Required(ErrorMessage = "Ban can phai nhap Mo ta !!!")]
        [Column(TypeName = "nvarchar(max)")]
        public string? Description { get; set; }

        [DisplayName("Hien thi gia: ")]
        [Range(5, 1000, ErrorMessage = "Gia cua san pham nam trong {1} - {2}")]
        [Required(ErrorMessage = "Ban can phai nhap Gia sp !!!")]
        [DataType(DataType.Currency)]
        public double Price { get; set; }

        [DataType(DataType.Date)]
        public DateTime Created { get; set; } = DateTime.Now;

        [DisplayName("Hien thi danh muc: ")]
        [Required(ErrorMessage = "Ban can phai nhap danh muc !!!")]
        [Column(TypeName = "nvarchar(50)")]
        public int? manu_ID { get; set; }

        [ForeignKey("Manufactures")]
        [Column(TypeName = "nvarchar(50)")]
        public Manufactures? Manufactures { get; set; }


    }
}
